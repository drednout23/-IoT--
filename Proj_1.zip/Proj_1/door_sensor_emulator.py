import time
import requests
import datetime
import os

BOT_TOKEN  = "7670114965:AAF5a5Hc7g-GGkuSbhGWPFDjyDhz7sotPnE"
CHAT_ID    = 1191566104
STATE_FILE = "door_state.txt"
LOG_FILE   = "log.txt"

def log_event(message):
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    entry = f"{timestamp} - {message}"
    try:
        with open(LOG_FILE, "a", encoding="utf-8") as log:
            log.write(entry + "\n")
    except Exception as e:
        print("Помилка запису логу:", e)
    return entry

def send_telegram_message(text):
    url = f"https://api.telegram.org/bot{BOT_TOKEN}/sendMessage"
    payload = {"chat_id": CHAT_ID, "text": text}
    try:
        requests.get(url, params=payload)
    except Exception as e:
        print("Помилка надсилання в Telegram:", e)

def write_state(state):
    with open(STATE_FILE, "w", encoding="utf-8") as f:
        f.write(state)

# Уведомление о запуске
send_telegram_message("✅ Емулятор запущено. Очікується вхід ON / OFF.")

print("ESP32 Геркон-емулятор запущено.")
print("Введіть 'ON' (відчинено) або 'OFF' (зачинено). Ctrl+C для виходу.\n")

prev_state = None
prev_time = time.time()

while True:
    try:
        user_input = input("Стан (ON/OFF): ").strip().upper()
        if user_input not in ["ON", "OFF"]:
            print("Некоректне значення. Введіть тільки 'ON' або 'OFF'.")
            continue

        current_time = time.time()
        elapsed = int(current_time - prev_time)
        state_text = "open" if user_input == "ON" else "closed"
        message = "Двері відчинено" if user_input == "ON" else "Двері зачинено"

        write_state(state_text)

        status_msg = f"Стан геркона: {'ВІДЧИНЕНО' if user_input == 'ON' else 'ЗАЧИНЕНО'}"
        if prev_state is not None:
            status_msg += f"\nТривалість попереднього стану: {elapsed} секунд"

        print(log_event(status_msg))  # Лог
        send_telegram_message(status_msg)  # Telegram

        prev_state = user_input
        prev_time = current_time

    except KeyboardInterrupt:
        print("\nЗавершення емуляції...")
        send_telegram_message("❌ Сеанс емулятора завершено.")
        break
    except Exception as e:
        print("Помилка:", e)
        time.sleep(2)
