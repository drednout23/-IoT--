import telebot
from telebot import types
import os

BOT_TOKEN = "7670114965:AAF5a5Hc7g-GGkuSbhGWPFDjyDhz7sotPnE"
STATE_FILE = "door_state.txt"
LOG_FILE = "log.txt"

bot = telebot.TeleBot(BOT_TOKEN)

def reply_menu():
    keyboard = types.ReplyKeyboardMarkup(resize_keyboard=True)
    keyboard.row("🟢 Стан геркона", "📜 Логи")
    return keyboard

@bot.message_handler(commands=['start'])
def handle_start(message):
    bot.send_message(message.chat.id, "✅ Бот запущено. Оберіть дію:", reply_markup=reply_menu())

@bot.message_handler(func=lambda message: "Стан геркона" in message.text)
def handle_status(message):
    try:
        with open(STATE_FILE, "r", encoding="utf-8") as f:
            state_text = f.read().strip()
    except FileNotFoundError:
        state_text = ""
    if state_text == "open":
        reply = "🔓 Зараз двері відчинені."
    elif state_text == "closed":
        reply = "🔒 Зараз двері зачинені."
    else:
        reply = "❔ Стан дверей наразі невідомий."
    bot.send_message(message.chat.id, reply, reply_markup=reply_menu())

@bot.message_handler(func=lambda message: "Логи" in message.text)
def handle_logs(message):
    try:
        with open(LOG_FILE, "r", encoding="utf-8") as f:
            logs = f.read()[-4000:]
        if not logs.strip():
            logs = "Логи ще порожні."
    except FileNotFoundError:
        logs = "Логи відсутні."
    bot.send_message(message.chat.id, f"📜 Останні логи:\n{logs.strip()}", reply_markup=reply_menu())

@bot.message_handler(func=lambda m: True)
def handle_all(message):
    bot.send_message(message.chat.id, "🤖 Скористайтеся кнопками нижче:", reply_markup=reply_menu())

if __name__ == '__main__':
    print("Door Monitor Bot is polling Telegram for new messages...")
    bot.polling(none_stop=True)
